from pathlib import Path
import sys, types, json, hashlib
ROOT=Path(r'C:/Users/luisi/.codex/worktrees/gat-ui-reporters/xDiyo')
SAVED=Path(r'C:/Users/luisi/AppData/Local/Temp/gat-speed-second-pass/first-pass')
sys.path[:0]=[str(ROOT/'src'),str(ROOT/'tests/analytics'),str(ROOT/'examples')]
import test_graph_speed

def reference():
    mods={}
    for name in ('store','preprocessing','streaming','adapter'):
        fullname='xdiyo_analytics.graphs._first_pass_'+name
        mod=types.ModuleType(fullname); mod.__package__='xdiyo_analytics.graphs'
        sys.modules[fullname]=mod
        path=SAVED/(name+'.py') if name!='adapter' else ROOT/'src/xdiyo_analytics/graphs/adapter.py'
        exec(compile(path.read_text(),str(path),'exec'),mod.__dict__)
        mods[name]=mod
    mods['adapter'].GraphPreprocessor=mods['preprocessing'].GraphPreprocessor
    mods['adapter'].GroupPlan=mods['streaming'].GroupPlan
    mods['adapter'].PreparedGroups=mods['streaming'].PreparedGroups
    return mods

test_graph_speed.reference=reference
import benchmark_gat_speed
benchmark_gat_speed.main()
output=Path(sys.argv[sys.argv.index('--output')+1]); report=json.loads(output.read_text())
report['mode']='first_pass'; report['baseline']='uncommitted first speed pass, source hashes pinned below'
report['comparison_source_sha256']={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in SAVED.glob('*.py')}
output.write_text(json.dumps(report,indent=2))
